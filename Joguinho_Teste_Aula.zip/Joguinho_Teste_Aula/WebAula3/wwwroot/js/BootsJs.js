﻿var objetoBoot = new Object();
objetoBoot.DivSite = "#conteudoBoot";
objetoBoot.LabelPontos = "#Pontos";
objetoBoot.LabelPontosRestante = "#PontosRestante";

objetoBoot.pontos = 0;
objetoBoot.vidas = 10;

objetoBoot.UltimoIdGerado = 0;

objetoBoot.listaBoots = [];

class Boot {
    constructor(window, $) {
        this._window = window;
        this._jquery = $;
    }

    inicilizarClasse(id, idDiv) {
        this.id = id;
        this.idDiv = idDiv;
        this.CriaBoot(this);
    }

    CriaBoot(Boot) {
        var divBoot = $("<div>").attr({ id: Boot.idDiv, class: "col-md-3 classDivBoot" });
        $(objetoBoot.DivSite).append(divBoot);
    }
}

function AdicionarFuncaoBotao() {
    $("#AdicionarBoot").click(function () {

        var idDiv = Math.floor(Math.random() * 1000 + 1);

        AdicionarBoot(1, idDiv);

        var carregaUltimo = 1;

        if (objetoBoot.UltimoIdGerado != 0) {

            carregaUltimo = VerificaAlinhamentoBoots(idDiv);

        }
        if (carregaUltimo > 0)
            objetoBoot.UltimoIdGerado = idDiv;


    });

    $("#LimparBoot").click(function () {
        $(objetoBoot.DivSite).html("");
    });
}


function Pontos() {

    $(objetoBoot.LabelPontosRestante).text(objetoBoot.vidas);
    $(objetoBoot.LabelPontos).text(objetoBoot.pontos);
}

function AdicionarBoot(id, idDiv) {
    var idClasse = objetoBoot.listaBoots.push(new Boot(window, jQuery, id, idDiv)) - 1;
    objetoBoot.listaBoots[idClasse].inicilizarClasse(id, idDiv);
}


function getCurrentRotation(elid) {
    var el = document.getElementById(elid);
    var st = window.getComputedStyle(el, null);
    var tr = st.getPropertyValue("-webkit-transform") ||
        st.getPropertyValue("-moz-transform") ||
        st.getPropertyValue("-ms-transform") ||
        st.getPropertyValue("-o-transform") ||
        st.getPropertyValue("transform") ||
        "fail...";

    if (tr !== "none") {
       
        var values = tr.split('(')[1];
        values = values.split(')')[0];
        values = values.split(',');
        var a = values[0];
        var b = values[1];
        var c = values[2];
        var d = values[3];

        var scale = Math.sqrt(a * a + b * b);
        var radians = Math.atan2(b, a);
        var angle = Math.round(radians * (180 / Math.PI));

        return Math.pow(b, 500);
    }
    else {
        var angle = 0;
    }

    return angle;
}

function VerificaAlinhamentoBoots(idDivGerado) {

    var retorno = 1;

    var ultimaDiv = getCurrentRotation(objetoBoot.UltimoIdGerado);
    var divAtual = getCurrentRotation(idDivGerado);


    if (ultimaDiv != divAtual) {

        objetoBoot.vidas--;
    }
    else {
        objetoBoot.pontos++;
    }

    if (objetoBoot.vidas == 0) {

        alert("Você perdeu, o jogo será reiniciado!");

        objetoBoot.pontos = 0;
        objetoBoot.vidas = 10;

        $(objetoBoot.DivSite).html("");
        objetoBoot.UltimoIdGerado = 0;

        retorno = 0;
    }

    Pontos();

    return retorno;
}


$(function () {
    AdicionarFuncaoBotao();
    Pontos();
});